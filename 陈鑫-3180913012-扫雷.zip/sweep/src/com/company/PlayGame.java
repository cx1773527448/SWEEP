package com.company;
//真正开始游戏的战场
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class PlayGame extends JFrame implements ActionListener,MouseListener{
    /**
     * 1.下拉框组件JComboBox
     *             //1.保存游戏
     *             //2.新开一局
     *             //3.背景音乐设置
     * 2.正式扫雷画面布置
     *
     */
    //定义雷区大小
    int c;
    int r;
    int boomsum;
    int count;
    //设置菜单
     JMenuBar menuBar;
     JMenu menu;
     JMenuItem save,restart,setting;

    //设置扫雷逻辑
     int [][]martix;
     node[][]nodeMartix;
     JButton[][]buttonMartix;
     JLabel l;

    //用map建立按钮于矩阵之间关系
    private Map<JButton,node> map=new HashMap<JButton,node>();
    //用hashset将随机找10个藏炸弹的点
    Set<node>set=new HashSet<node>();

    //图片
    String imageBoom=new String("src\\images\\boomf.jpg");
    String imageGery=new String("src\\images\\grey.png");
    String imageRed=new String("src\\images\\red.png");
    String imagePink =new String("src\\images\\pink.png");
    String imageWhite=new String("src\\images\\white.png");
    //数字
    String one=new String("src\\images\\number\\One.png");
    String two=new String("src\\images\\number\\Two.png");
    String three=new String("src\\images\\number\\Three.png");
    String four=new String("src\\images\\number\\Four.png");
    String five=new String("src\\images\\number\\Five.png");
    String six=new String("src\\images\\number\\Six.png");
    String seven=new String("src\\images\\number\\Seven.png");
    String eight=new String("src\\images\\number\\Eight.png");

    //小旗子
    String red=new String("E:\\webProject\\application\\sweep\\src\\images\\red.png");
    PlayGame(int cols,int rows,int boomSum)
    {

        this.c=cols;
        this.r=rows;
        this.boomsum=boomSum;
        this.count=boomSum;
        //初始化行列
        martix=new int[this.c][this.r];
        nodeMartix=new node[this.c][this.r];
        buttonMartix=new JButton[this.c][this.r];
        //创建菜单
        menuBar=new JMenuBar();
        menu=new JMenu("选项");
        save=new JMenuItem("保存");
        restart=new JMenuItem("重新开始");
        setting=new JMenuItem("音乐设置");
        //菜单添加
       // menuBar.setBorderPainted(false);
        menuBar.add(menu);
        menu.add(save);
        menu.add(restart);
        menu.add(setting);

        menuBar.setSize(100,500);
        //设置面板
        JPanel p=new JPanel();
        JPanel p1=new JPanel();
        JPanel p2=new JPanel();

        l=new JLabel("雷的总个数："+count);
        l.setBounds(0,0,100,500);
        p1.add(menuBar);
        p2.add(l);
        p.setLayout(new GridLayout(this.c,this.r));

        /** 设置矩阵
         *
         */
        //创建矩阵，将矩阵初始化为-1
       // martix=new int[this.c][this.r];
        for(int i=0;i<martix.length;i++)
        {
            for(int j=0;j<martix[0].length;j++)
            {
                martix[i][j]=-1;
                //martix[i][j]=(int)Math.random()*10;
            }
        }
        //用hashset将随机找10个藏炸弹的点

        while(set.size()<=this.boomsum)
        {
            int x=(int)(Math.random()*this.c);
            int y=(int)(Math.random()*this.r);
            node n=new node(x,y);
            set.add(n);
        }
        //藏炸弹的点赋值为0，将10个点赋值
        Object[]nodes=set.toArray();
        for(int j=0;j<nodes.length;j++)
        {
            martix[((node)nodes[j]).i][((node)nodes[j]).j]=0;
        }

        //为按钮添加监听器,并把按钮添加到面板上
        for(int i=0;i<this.r;i++)
        {
            for(int j=0;j<this.c;j++)
            {
                ImageIcon icon=new ImageIcon(imageGery);

                JButton button=new JButton(icon);
            /*    button.addActionListener(new ActionListener()
                                         {
                                             @Override
                                             public void actionPerformed(ActionEvent e) {
                                                 node n=map.get(button);
                                                 sweep(n.i,n.j);
                                             }
                                         }
                );*/
                button.addMouseListener(new MouseListener() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if(e.getButton()==MouseEvent.BUTTON3)
                        {
                            ImageIcon i=new ImageIcon(red);
                            //button.setIcon(i);
                            node t=map.get(button);
                            button.setIcon(i);
                            if(set.contains(t))
                                --count;
                            l.setText("雷的总个数："+count);
                           // buttonMartix[t.i][t.j].setIcon(i);
                        }
                        else if(e.getButton()==MouseEvent.BUTTON1)
                        {
                            node n=map.get(button);

                            sweep(n.i,n.j);
                            if(count==0)
                            {
                                int n1 = JOptionPane.showConfirmDialog(null, "再来一局", "恭喜通关",JOptionPane.YES_NO_OPTION);//返回的是按钮的index  i=0或者1
                                if(0==n1) {
                                    dispose();//销毁当前窗体
                                    new PlayGame(r, c,boomsum );
                                }
                                else
                                {

                                    System.exit(0);
                                }
                            }


                        }
                    }

                    @Override
                    public void mousePressed(MouseEvent e) {

                    }

                    @Override
                    public void mouseReleased(MouseEvent e) {

                    }

                    @Override
                    public void mouseEntered(MouseEvent e) {

                    }

                    @Override
                    public void mouseExited(MouseEvent e) {

                    }
                });
                p.add(button);

                //将位置于按钮放在map
               node n1=new node(i,j);
               map.put(button,n1);
               nodeMartix[i][j]=n1;
               buttonMartix[i][j]=button;
            }
        }

        this.setLayout(null);

        p1.setBounds(0,0,200,50);
        p2.setBounds(450,0,200,50);
        p.setBounds(0,50,1200,1100);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // this.getContentPane().add(p1);
        this.getContentPane().add(p);
        this.getContentPane().add(p2);
        this.setBounds(200,200,1225,1225);
        this.setTitle("SWEEP");
        this.setVisible(true);

    }

    //设置地雷搜索
    public int smallSweep(int x,int y)
    {
        //if(-1==mar[x][y])
        if(x<0||y<0||x>=martix.length||y>=martix[0].length)
            return Integer.MAX_VALUE;
        if(-2==martix[x][y])
            return -2;
        if(0==martix[x][y])
            return -1;
        int sum=0;
        for(int i=(x<=0?x:x-1);i<=(x>=martix[0].length-1?x:x+1);i++)
            for(int j=(y<=0?y:y-1);j<=(y>=martix.length-1?y:y+1);j++)
            {
                if(0==martix[i][j])
                    ++sum;
            }
        return sum;
    }
    public void sweep(int i,int j)
    {
        if(-1==smallSweep(i,j))
        {
            ImageIcon icon=new ImageIcon(imageBoom);
            Object[]obj=set.toArray();
            for(int k=0;k<obj.length;k++)
            {
                buttonMartix[((node)obj[k]).i][((node)obj[k]).j].setIcon(icon);
            }
            //图标再来一局
            int n = JOptionPane.showConfirmDialog(null, "再来一局", "提示",JOptionPane.YES_NO_OPTION);//返回的是按钮的index  i=0或者1
            if(0==n) {
                dispose();//销毁当前窗体
                new PlayGame(this.r, this.c,this.boomsum );
            }
            else
            {

                System.exit(0);
            }

        }
        else if(0==smallSweep(i,j))
        {
            martix[i][j]=-2;
            ImageIcon icon=new ImageIcon(imageWhite);
            buttonMartix[i][j].setIcon(icon);

            sweep(i-1,j);
            sweep(i+1,j);
            sweep(i,j+1);
            sweep(i,j-1);
            sweep(i-1,j-1);
            sweep(i+1,j-1);
            sweep(i-1,j+1);
            sweep(i+1,j+1);

        }
        else if(0<smallSweep(i,j)&&smallSweep(i,j)<=8)
        {
            ImageIcon icon=new ImageIcon(imageWhite);
            buttonMartix[i][j].setIcon(icon);
            if(smallSweep(i,j)==1)
            {
                ImageIcon a=new ImageIcon(one);
                buttonMartix[i][j].setIcon(a);
            }
            else if(smallSweep(i,j)==2)
            {
                ImageIcon b=new ImageIcon(two);
                buttonMartix[i][j].setIcon(b);
            }
            else if(smallSweep(i,j)==3)
            {
                ImageIcon c=new ImageIcon(three);
                buttonMartix[i][j].setIcon(c);
            }
            else if (smallSweep(i,j)==4)
            {
                ImageIcon d=new ImageIcon(four);
                buttonMartix[i][j].setIcon(d);
            }
            else if(smallSweep(i,j)==5)
            {
                ImageIcon e =new ImageIcon(five);
                buttonMartix[i][j].setIcon(e);
            }
            else if(smallSweep(i,j)==6)
            {
                ImageIcon f=new ImageIcon(six);
                buttonMartix[i][j].setIcon(f);
            }
            else if(smallSweep(i,j)==7)
            {
                ImageIcon g=new ImageIcon(seven);
                buttonMartix[i][j].setIcon(g);
            }
            else if(smallSweep(i,j)==8)
            {
                ImageIcon h=new ImageIcon(eight);
                buttonMartix[i][j].setIcon(h);
            }
            else
            {

            }
        }
        else if(-2==smallSweep(i,j))
        {
            return ;
        }
        else
        {

        }
        return;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
class node
{
    public int i;
    public int j;
    node(int x,int y)
    {
        this.i=x;
        this.j=y;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        node node = (node) o;
        return i == node.i &&
                j == node.j;
    }

    @Override
    public int hashCode() {
        return Objects.hash(i, j);
    }
}
