package com.company;

import com.sun.java.swing.plaf.windows.WindowsButtonListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static java.lang.Thread.sleep;

//用于写开始界面的类
class MyFrame extends JFrame implements ActionListener {

     // 1.开始游戏
     // 2.继续游戏
     // 3.设置难度
     // 4.退出游戏
    //定义按钮
     JButton b1,b2,b3,b4;
     JLabel j;
     int rows=10,colums=10,boomsum=10;
    MyFrame()
    {
        //添加面板

        //ImageIcon icon=new ImageIcon("E:\\webProject\\application\\sweep\\src\\images\\h1.jpg");
        ImageIcon icon=new ImageIcon("E:\\webProject\\application\\sweep\\src\\images\\gunnerb.jpg");
        j=new JLabel(icon);
        //创建按钮
        b1=new JButton("开始游戏");
        b2=new JButton("继续游戏");
        b3=new JButton("设置难度");
        b4=new JButton("退出游戏");
        //增添监听器;
        b1.addActionListener(new ActionListener()
                             {
                                 @Override
                                 public void actionPerformed(ActionEvent e) {
                                     dispose();
                                     new PlayGame(rows,colums,boomsum);
                                 }
                             }
        );
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new PlayGame(rows,colums,boomsum);
            }
        });


        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                SetGame g=new SetGame();

            }
        });

        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        //设置字体大小
        b1.setFont(new Font("",Font.BOLD,22));
        b2.setFont(new Font("",Font.BOLD,22));
        b3.setFont(new Font("",Font.BOLD,22));
        b4.setFont(new Font("",Font.BOLD,22));

        //设置按钮大小
        b1.setBounds(450,200,300,100);
        b2.setBounds(450,350,300,100);
        b3.setBounds(450,500,300,100);
        b4.setBounds(450,650,300,100);

        //添加监听器


        //添加按钮
        this.getContentPane().add(b1);
        this.getContentPane().add(b2);
        this.getContentPane().add(b3);
        this.getContentPane().add(b4);
        this.getContentPane().add(j);
        //设置窗体
        this.setTitle("SWEEP");
        this.setBounds(200,200,1200,1200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


    }
    @Override
    public void actionPerformed(ActionEvent e)
    {

    }


}
