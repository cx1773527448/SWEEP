package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        //System.out.print("Hello world!");
        new MyFrame();
       //new PlayGame(13,13,17);
    }
}
