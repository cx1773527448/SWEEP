package com.company;

import java.awt.*;
import java.beans.PropertyChangeListener;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
//简单的游戏难度设置
public  class SetGame extends JFrame  {

    static JButton b1;
    static JButton b2;
    static JButton b3;
    JLabel l;



    SetGame()
    {

        b1=new JButton();
        b2=new JButton();
        b3=new JButton();
        l=new JLabel();

        l.setText("");
        b1.setText("容易");
        b2.setText("一般");
        b3.setText("困难");
        getArr();
        b1.setFont(new Font("",Font.BOLD,22));
        b2.setFont(new Font("",Font.BOLD,22));
        b3.setFont(new Font("",Font.BOLD,22));

        //设置按钮大小
        b1.setBounds(450,200,300,100);
        b2.setBounds(450,350,300,100);
        b3.setBounds(450,500,300,100);

        //添加监听器


        //添加按钮
        this.getContentPane().add(b1);
        this.getContentPane().add(b2);
        this.getContentPane().add(b3);
        this.getContentPane().add(l);
        //设置窗体
        this.setTitle("SWEEP");
        this.setBounds(200,200,1200,1200);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);




    }
    synchronized public void getArr() {
        b1.addActionListener(new ActionListener() {
            @Override
            synchronized  public void actionPerformed(ActionEvent e) {
                dispose();
                new PlayGame(10,10,10);
            }
        });
        b2.addActionListener(new ActionListener() {
            @Override
            synchronized  public void actionPerformed(ActionEvent e) {
                dispose();
                new PlayGame(12,12,12);
            }
        });
        b3.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new PlayGame(14,14,14);
            }
        });
       }


}
